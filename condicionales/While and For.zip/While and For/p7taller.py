max = int(input("DIGITE UN NÚMERO "))
suma = 0
n = 0
while suma <= max:
    n += 1
    suma += n

print(f"EL NÚMERO NATURAL MAS PEQUEÑO ES {n}")
