num = input("DIGITE UN NUMERO ") 
ni = "" 
for i in num: 
    ni = i + ni 
 
print(f"EL NUMERO INVERSO ES{ni}")