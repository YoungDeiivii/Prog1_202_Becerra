n = int(input("ESCRIBA UN NUMERO "))

print("LOS MULTIPLOS DEL NUMERO 5 SON")
for i in range(1, n + 1):
    if i % 5 == 0:
      print (i) 