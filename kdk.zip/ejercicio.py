'''
estudiantes_matematicas = {"Ana", "Juan", "Luis", "Maria","John","Mary","Pedro"}
estudiantes_fisica = {"Juan", "Maria", "Carlos", "Pedro","Eliana","Laura"}
Mostrar:
1.Todas las personas que son estudiantes
2.Los que solo ven Matemáticas y los que solo ven física
3. Los que ven las dos materias
4. Los que solo ven una asignatura, independientemente de cuál sea
5. Los que ven las dos materias'''

estudiantes_matematicas = {"Ana", "Juan", "Luis", "Maria","John","Mary","Pedro"}
estudiantes_fisica = {"Juan", "Maria", "Carlos", "Pedro","Eliana","Laura"}
#1
union=estudiantes_matematicas|estudiantes_fisica
print(f"union ={union} ")
#2
estudiantes_matematicas = {"Ana", "Juan", "Luis", "Maria", "John", "Mary", "Pedro"}
estudiantes_fisica = {"Juan", "Maria", "Carlos", "Pedro", "Eliana", "Laura"}


solo_matematicas = estudiantes_matematicas.difference(estudiantes_fisica)
solo_fisica = estudiantes_fisica.difference(estudiantes_matematicas)


print("2. Estudiantes que solo ven Matemáticas:", solo_matematicas)
print("2. Estudiantes que solo ven Física:", solo_fisica)

#3
inter=estudiantes_matematicas&estudiantes_fisica# que tienen en comun 
print(f"lo que tienen en comun es{inter} ")

#4
estudiantes_matematicas = {"Ana", "Juan", "Luis", "Maria","John","Mary","Pedro"}
estudiantes_fisica = {"Juan", "Maria", "Carlos", "Pedro","Eliana","Laura"}
dif=estudiantes_fisica-estudiantes_matematicas
print(f"la diferencia={dif}")

