#2

t1 = (1, 2, 3, 4, 5)
t2 = (5, 6, 7, 8, 9)

def sumaTupla(tupla):
    suma = 0
    for x in tupla:
        suma += x
    print(f"Suma de {tupla}: {suma}")
    return suma

suma1 = sumaTupla(t1)
suma2 = sumaTupla(t2)

def comparaSumas(tupla1, tupla2):
    s1 = sumaTupla(tupla1)
    s2 = sumaTupla(tupla2)
    if s1 > s2:
        print(f"s1 es mayor = {s1}")
        return f"s1 es mayor = {s1}"
    elif s2 > s1:
        print(f"s2 es mayor = {s2}")
        return f"s2 es mayor = {s2}"
    else:
        print("Las sumas son iguales")
        return "Las sumas son iguales"

comparaSumas(t1, t2)

def mayorTupla(tupla):
    mayor = max(tupla)
    print(f"Mayor de {tupla}: {mayor}")
    return mayor

mayor1 = mayorTupla(t1)
mayor2 = mayorTupla(t2)

def menorTupla(tupla):
    menor = min(tupla)
    print(f"Menor de {tupla}: {menor}")
    return menor

menor1 = menorTupla(t1)
menor2 = menorTupla(t2)
if menor1<menor2:
    print('la tulpa 2 contiene el numero mayor',{menor2} )
elif menor1>menor2:
    print('la tupla2 contiene el numero maroe',{menor1 } )

def promedioTupla(tupla):
    promedio = sumaTupla(tupla) / len(tupla)
    print(f"Promedio de {tupla}: {promedio}")
    return promedio

promedio1 = promedioTupla(t1)
promedio2 = promedioTupla(t2)

def cuentaPares(tupla):
    pares = sum(1 for x in tupla if x % 2 == 0)
    print(f"Cantidad de pares en {tupla}: {pares}")
    return pares

pares1 = cuentaPares(t1)
pares2 = cuentaPares(t2)

def cuentaImpares(tupla):
    impares = sum(1 for x in tupla if x % 2 != 0)
    print(f"Cantidad de impares en {tupla}: {impares}")
    return impares

impares1 = cuentaImpares(t1)
impares2 = cuentaImpares(t2)
#3 

cantidad = int(input("Ingrese la cantidad de dígitos para la serie de Fibonacci: "))

fibonacci = (0, 1)


for _ in range(2, cantidad):
    siguiente = fibonacci[-1] + fibonacci[-2]
    fibonacci += (siguiente,)  


print("Serie de Fibonacci:", fibonacci)

#4
import random

n = int(input("Ingrese el número de elementos: "))
arreglo = []
for _ in range(n):
    numero = random.randint(1, 10)
    while numero in arreglo:
        print(f"El número {numero} ya está en el arreglo")
        numero = random.randint(1, 10)
    arreglo.append(numero)

print("Arreglo generado:", arreglo)
#5. Llenar un arreglo de n elementos con números generados con la función random.
def generararreglo(n):
    arreglo = []
    numeroanterior = 0
    for i in range(n):
        siguientedecena = (numeroanterior // 10 + 1) * 10
        numero = random.randint(numeroanterior + 1, siguientedecena - 1)
        arreglo.append(numero)
        numeroanterior = numero
    return tupla(arreglo)
#6.-Si el elemento esta por encima del promedio, debajo o es igual
def compararconpromedio(arreglo):
    promedio = sum(arreglo) / len(arreglo)
    comparaciones = []
    
    for numero in arreglo:
        if numero > promedio:
            comparaciones.append(f'{numero} está por encima del promedio')
        elif numero < promedio:
            comparaciones.append(f'{numero} está debajo del promedio')
        else:
            comparaciones.append(f'{numero} es igual al promedio')
    
    return comparaciones
comparaciones = compararconpromedio(arreglo)
for comparacion in comparaciones:
    print(comparacion)
#7.Función para verificar si un número es primo
def esprimo(numero):
    if numero < 2:
        return False
    for i in range(2, int(numero ** 0.5) + 1):
        if numero % i == 0:
            return False
    return True
def primosenarreglo(arreglo):
    primos = [numero for numero in arreglo if esprimo(numero)]
    return len(primos), primos


cantidadprimos, primos = primosenarreglo(arreglo)
print(f'Cantidad de primos: {cantidadprimos}')
print(f'Primos encontrados: {primos}')



#9
def burbuja_orden(arreglo, orden="asc"):
    lista = list(arreglo)
    for i in range(len(lista)):
        for j in range(0, len(lista) - i - 1):
            if (orden == "asc" and lista[j] > lista[j + 1]) or (orden == "desc" and lista[j] < lista[j + 1]):
                lista[j], lista[j + 1] = lista[j + 1], lista[j]
    return tuple(lista)

arreglo = (8, 3, 1, 7, 4, 5)
orden_ascendente = burbuja_orden(arreglo, "asc")
print("Orden ascendente:", orden_ascendente)

orden_descendente = burbuja_orden(arreglo, "desc")
print("Orden descendente:", orden_descendente)


#10
def buscarnumero(arreglo, numero):
    posiciones = [i for i, x in enumerate(arreglo) if x == numero]
    cantidad = len(posiciones)
    return cantidad, posiciones


numero_buscar = 15 
cantidad, posiciones = buscarnumero(arreglo, numerobuscar)
print(f"El número {numerobuscar} aparece {cantidad} veces en las posiciones: {posiciones}")
#11
import math

def hallarfactoriales(lista):
    factoriales = [math.factorial(num) for num in lista]
    return factoriales

numeros = [2, 5, 8, 10, 12]  
factoriales = hallarfactoriales(numeros)
print(f"Factoriales de los números en la lista: {factoriales}")

